import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.*;
import java.util.Random;




public class PlayWindow extends JFrame  implements KeyListener, ActionListener
{
	    int ROWS = 20;
		int COLS = 20;
		private final int TIME_DELAY = 500;
		int key;

		boolean goingUp = true;
		boolean goingDown = false;
		boolean goingLeft = false;
		boolean goingRight = false;
		
				
		private JLabel [][] screen = new JLabel[ROWS][COLS];
		private JLabel positionLabel;
		private JFrame frame;
		private JPanel basePanel, playAreaPanel, scorePanel;	
		
		private Snake mySnake;
	    private SnakeElement apple;
		private SnakeElement snakeHead;
		private SnakeElement oldSnakeHead;
		private javax.swing.Timer timer;  
		
		
	PlayWindow()
	{
		super("Welcome to Snake");
		
		
		
		//Create and set up the window
		frame = this;
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize (ROWS*40,COLS*40);
		
		// Create Panel for Score and other info		
		scorePanel = new JPanel();
		positionLabel = new JLabel("x:y");
		scorePanel.add(positionLabel);
		
		//create panel with playing grid
		playAreaPanel = new JPanel();
	    playAreaPanel.setSize (ROWS*50,COLS*50);
		GridLayout playLayout = new GridLayout(ROWS,COLS,0,0);
		playAreaPanel.setLayout(playLayout);
		playAreaPanel.addKeyListener(this);
		//create 2D Array of Lables
		for (int row = 0; row < ROWS; row ++)
			for (int col = 0; col< COLS; col ++)
			{
				screen[row][col] = new JLabel("X");
				playAreaPanel.add(screen[row][col]);
				screen[row][col].setVisible(false);
			}
		
		
		oldSnakeHead = new SnakeElement();
		snakeHead = new SnakeElement();
		
		mySnake = new Snake();
		oldSnakeHead = mySnake.createInitialSnake(ROWS/2,COLS/2,5);
		
		//Add panels to BasePanel
		basePanel =new JPanel();
		BorderLayout bLayout = new BorderLayout();
		basePanel.setLayout(bLayout);
		basePanel.add(scorePanel, BorderLayout.NORTH);
		basePanel.add(playAreaPanel, BorderLayout.CENTER);
		frame.add(basePanel);
		playAreaPanel.setFocusable(true);
		playAreaPanel.requestFocusInWindow();
		frame.setVisible(true);
		timer = new javax.swing.Timer(TIME_DELAY, new TimerListener());
        timer.start();
		addApple();
		
	}
   public void addApple()
	{
		Random randomNumbers = new Random();
		
		
		int appleRow = 0;
		int appleCol = 0;
		
		boolean applePlanted = false;
		while (!applePlanted)
		{
			appleRow = randomNumbers.nextInt(ROWS); //nextInt(n) produce random number from 0-(n-1) we want a number from 1-(ROWS)
			appleCol = randomNumbers.nextInt(COLS);
			apple = new SnakeElement(appleRow,appleCol);
			System.out.printf("%d,%d",appleRow,appleCol);
			if (!mySnake.isMember(apple)) // apple not in snake
			{
				 screen[apple.getRow()][apple.getCol()].setText("O");
				 screen[apple.getRow()][apple.getCol()].setVisible(true);
				 applePlanted = true;
			}
			
		}
		
	}
	public void paint(Graphics g) {
        // Call the superclass paint method.
        super.paint(g);
    }	

	@Override
	public void actionPerformed(ActionEvent e) {
       	    playAreaPanel.requestFocusInWindow();
    }
	@Override
	public void keyPressed(KeyEvent e) 
	{				
		key = e.getKeyCode();
		if (key == KeyEvent.VK_LEFT)
		{
			goingUp = goingDown =  goingRight = false;
			goingLeft = true;
		}
		if (key == KeyEvent.VK_UP)
		{
			goingLeft = goingDown =  goingRight = false;
			goingUp = true;
			
		}
		if (key == KeyEvent.VK_RIGHT)
		{
			goingLeft = goingDown =  goingUp = false;
			goingRight = true;
			
		}
		if (key == KeyEvent.VK_DOWN)
		{
			goingLeft = goingUp =  goingRight = false;
			goingDown = true;
		}
	}
	
	@Override
	public void keyReleased(KeyEvent e) { 
	
	}
	@Override
	public void keyTyped(KeyEvent e) {}
    
	private class TimerListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
           					
			snakeHead= new SnakeElement();
			snakeHead.setRow(oldSnakeHead.getRow());	
			snakeHead.setCol(oldSnakeHead.getCol());
			System.out.printf("\n timer before: %d : %d \n",snakeHead.getRow(),snakeHead.getCol());
			
            if (goingUp) 
			{
				snakeHead.decrementRow();
			}
			if (goingDown)
			{
				snakeHead.incrementRow();
			}
			if (goingLeft)
			{
				snakeHead.decrementCol();
			}
			if (goingRight)
			{
				snakeHead.incrementCol();
			}
			positionLabel.setText(String.valueOf(snakeHead.getRow()) +":"+String.valueOf(snakeHead.getCol()));
			System.out.printf("\n timer old: %d : %d \n",oldSnakeHead.getRow(),oldSnakeHead.getCol());
			System.out.printf("\n timer new: %d : %d \n",snakeHead.getRow(),snakeHead.getCol());
			if  (snakeHead.compareTo(apple)==0)
			{
				mySnake.grow(snakeHead);
				 screen[apple.getRow()][apple.getCol()].setText("X");
				 screen[apple.getRow()][apple.getCol()].setVisible(true);
				addApple();
				
			}
			else
				mySnake.moveForward(snakeHead);
		
			oldSnakeHead.setRow(snakeHead.getRow());
			oldSnakeHead.setCol(snakeHead.getCol());
		}
	}
	
	public class Snake 
	{ 
	    int maxLength= (ROWS * COLS)-1;
		QueueAsSLL <SnakeElement> theSnake = new QueueAsSLL <SnakeElement>();
		int snakeLength=0;
		
		public Snake()
		{
			snakeLength = 0;
		}
		public SnakeElement createInitialSnake(int row, int col, int size)
		{
			SnakeElement temp=new SnakeElement();
			SnakeElement tt=new SnakeElement();
			// create small snake to start with
			int i;
			for (i = (size-1); i>=0; i--) // Swapped order
			{
				temp = null;
				temp = new SnakeElement(row,col+i);
				theSnake.enqueue(temp);
				screen[row][col+i].setVisible(true);
			}
			snakeLength = size;
			System.out.printf("New Snake %s \n",theSnake);
			tt.deepCopy(temp);
			return tt;
		}

		public void moveForward(SnakeElement newHead)
		{
			SnakeElement t,t1;
			if (snakeLength < maxLength && snakeLength >0)
			{
				t=(SnakeElement) theSnake.dequeue();
				screen[t.getRow()][t.getCol()].setVisible(false);
				t1=new SnakeElement(newHead.getRow(),newHead.getCol());
				if (theSnake.isMember(t1))
				{
					
					timer.stop();	
					JOptionPane.showMessageDialog(frame, "GAME OVER");
				}
				else
				{
					if (theSnake.enqueue(t1))
						screen[newHead.getRow()][newHead.getCol()].setVisible(true);
					System.out.printf("Forward Snake %s \n",theSnake);
				}
			}			
		}
		public void grow(SnakeElement newHead)
		{
			SnakeElement t,t1;
			if (snakeLength < maxLength && snakeLength >0)
			{
				t1=new SnakeElement(newHead.getRow(),newHead.getCol());
				if (theSnake.enqueue(t1))
				    screen[newHead.getRow()][newHead.getCol()].setVisible(true);
				System.out.printf("Forward Snake %s \n",theSnake);
			}			
		}
		public boolean isMember(SnakeElement item) 
		{
			return theSnake.isMember(item);
		}
		public int getSize()
		{
			return snakeLength;
		}
	}
		
	
	public class SnakeElement implements Comparable<SnakeElement>
	{
		int rowPos;
		int colPos;
		
		public SnakeElement()
		{
			this(0,0);
		}
		
		public SnakeElement(int r, int c)
		{
			if (r<ROWS)
				rowPos=r;
			else
				rowPos=0;
			if (c<COLS)
				colPos=c;
			else
				colPos=0;
		}
		
		void deepCopy(SnakeElement param)
		{
           rowPos=param.rowPos;
		   colPos=param.colPos;
		}
		
		void incrementRow()
		{
			if (rowPos < (ROWS-1))
			{
				rowPos++;
			}
			else
			{
				rowPos = 0;
			}
		}
		void decrementRow()
		{
			if (rowPos > 0)
			{
				rowPos--;
			}
			else
			{
				rowPos = ROWS-1;
			}
		}
		void incrementCol()
		{
			if (colPos < (COLS-1))
			{
				colPos++;
			}
			else
			{
				colPos = 0;
			}
		}
		void decrementCol()
		{
			if (colPos > 0)
			{
				colPos--;
			}
			else
			{
				colPos = COLS-1;
			}
		}
		int getRow ()
		{
			return rowPos;
		}
		void setRow (int r)
		{
			rowPos = r;
		}
		int getCol ()
		{
			return colPos;
		}
		void setCol (int c)
		{
			colPos =c;
		}	
	
	 @Override
		public String toString()
		{
			String s = "("+rowPos+ "," +colPos+")";
			return s;
		}
  	@Override
		public int compareTo(SnakeElement param)
		{
			if (param.colPos==colPos && param.rowPos==rowPos)
				return 0;
			else return -1;
		}
	}
	
	
 public static void main(String[] args) 
	{
		SwingUtilities.invokeLater(new Runnable() 
		{
			@Override
			public void run() {
				new PlayWindow().setVisible(true);
			}
		});
	}

}